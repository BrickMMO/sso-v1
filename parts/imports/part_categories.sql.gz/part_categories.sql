-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 15, 2023 at 07:27 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brickmmo_parts`
--

-- --------------------------------------------------------

--
-- Table structure for table `part_categories`
--

CREATE TABLE `part_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `part_categories`
--

INSERT INTO `part_categories` (`id`, `name`) VALUES
(1, 'Baseplates'),
(3, 'Bricks Sloped'),
(4, 'Duplo, Quatro and Primo'),
(5, 'Bricks Special'),
(6, 'Bricks Wedged'),
(7, 'Containers'),
(8, 'Technic Bricks'),
(9, 'Plates Special'),
(11, 'Bricks'),
(12, 'Technic Connectors'),
(13, 'Minifigs'),
(14, 'Plates'),
(15, 'Tiles Special'),
(16, 'Windows and Doors'),
(17, 'Non-LEGO'),
(18, 'Hinges, Arms and Turntables'),
(19, 'Tiles'),
(20, 'Bricks Round and Cones'),
(21, 'Plates Round Curved and Dishes'),
(22, 'Pneumatics'),
(23, 'Panels'),
(24, 'Other'),
(25, 'Technic Steering, Suspension and Engine'),
(26, 'Technic Special'),
(27, 'Minifig Accessories'),
(28, 'Plants and Animals'),
(29, 'Wheels and Tyres'),
(30, 'Tubes and Hoses'),
(31, 'String, Bands and Reels'),
(32, 'Bars, Ladders and Fences'),
(33, 'Rock'),
(34, 'Supports, Girders and Cranes'),
(35, 'Transportation - Sea and Air'),
(36, 'Transportation - Land'),
(37, 'Bricks Curved'),
(38, 'Flags, Signs, Plastics and Cloth'),
(39, 'Magnets and Holders'),
(40, 'Technic Panels'),
(41, 'Large Buildable Figures'),
(42, 'Belville, Scala and Fabuland'),
(43, 'Znap'),
(44, 'Mechanical'),
(45, 'Electronics'),
(46, 'Technic Axles'),
(47, 'Windscreens and Fuselage'),
(48, 'Clikits'),
(49, 'Plates Angled'),
(50, 'HO Scale'),
(51, 'Technic Beams'),
(52, 'Technic Gears'),
(53, 'Technic Pins'),
(54, 'Technic Bushes'),
(55, 'Technic Beams Special'),
(56, 'Tools'),
(57, 'Non-Buildable Figures (Duplo, Fabuland, etc)'),
(58, 'Stickers'),
(59, 'Minifig Heads'),
(60, 'Minifig Upper Body'),
(61, 'Minifig Lower Body'),
(62, 'Minidoll Heads'),
(63, 'Minidoll Upper Body'),
(64, 'Minidoll Lower Body'),
(65, 'Minifig Headwear'),
(66, 'Modulex'),
(67, 'Tiles Round and Curved'),
(68, 'Projectiles / Launchers');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `part_categories`
--
ALTER TABLE `part_categories`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
